
import random
print("Welcome to the guessing number game ")
print("I am thinking number between 1 to 100 ")
choose = input("Choose a difficulty, type easy or hard : ")
number_list=[]
for i in range(1,100):
  number_list.append(i)
number=random.choice(number_list)
attempt_hard = 5
attempt_easy=10
is_gameover=False
i=1
if choose =="hard":
  #print(f"you have the {attempt-1}times to guess number ")
  while i<=5:
    guess=int(input("guess the number : "))
    attempt_hard-=1
    print(f" you have the {attempt_hard} times to guess number")
    if guess >number:
          print("high")
          if i < 5:
           print("guess again")
          elif i==5:
            print("over")
          i+=1
    elif guess<number:
        print("low")
        if i < 5:
         print("guess again")
        elif i == 5:
          print("over")
        i+=1
    elif guess==number:
        print("yes this number")
        break
if choose == "easy":
   while i<=10:
    guess=int(input("guess the number : "))
    attempt_easy-=1
    print(f" you have the {attempt_easy} times to guess number")
    if guess >number:
          print("high")
          if i < 5:
           print("guess again")
          elif i==5:
            print("over")
          i+=1
    elif guess<number:
        print("low")
        if i < 5:
         print("guess again")
        elif i == 5:
          print("over")
        i+=1
    elif guess==number:
        print("yes this number")
        break